export interface Request{
    UserName: string;
    imageUrl: string;
}