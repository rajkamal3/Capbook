import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'pm-statusupdate',
  templateUrl: './statusupdate.component.html',
  styleUrls: ['./statusupdate.component.css']
})
export class StatusupdateComponent implements OnInit {
 
  constructor() { }

  ngOnInit() {
  }

}
