/* import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'pm-bdays',
  templateUrl: './bdays.component.html',
  styleUrls: ['./bdays.component.css']
})
export class BdaysComponent implements OnInit {

  pageTitle: string = 'bdays';

  constructor() { }

  ngOnInit() {
  }

}
 */

import { Component, OnInit } from '@angular/core';
import { IBirthday } from '../bdayy'
import { CustserviceService } from '../custservice.service';
@Component({
  selector: 'app-birthday',
  templateUrl: './bdays.component.html',
  styleUrls: ['./bdays.component.css']
})
export class BdaysComponent implements OnInit {

  birthdaydetails: IBirthday[] = []


  constructor(private custService: CustserviceService) { }

  ngOnInit() {

    //this.getDetails1(10);
    //this.getDetails(10);

  }

  getDetails2() {

    this.getDetails1(10);

    if (this.birthdaydetails = []) {

      this.getDetails(10);
    }

    // this.getDetails1(100);
  }
  getDetails1(userId: number): void {
    this.custService.getDetails1(userId)
      .subscribe(birthdaydetails => {
        console.log(this.birthdaydetails);
        this.birthdaydetails = birthdaydetails;
      })
  }
  getDetails(userId: number): void {
    this.custService.getDetails(userId)
      .subscribe(birthdaydetails => {
        console.log(this.birthdaydetails);
        this.birthdaydetails = birthdaydetails;

      }, (error) => {
        return false;
      })
  }

}

