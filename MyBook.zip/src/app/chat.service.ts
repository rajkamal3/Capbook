import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders } from '@angular/common/http';

import { Chat, Messages } from './chat/chat';
import { Observable } from '../../node_modules/rxjs/Observable';
@Injectable()
export class ChatService {

  constructor(private http:HttpClient) {}
  private userUrl = 'http://localhost:8084/api/chat/chats/';
  private userUrl1 = 'http://localhost:8084/api/chat/';
 

  public getMessages(chat:Chat):Observable<Messages[]>{
    
    return this.http.get<Messages[]>(this.userUrl+chat.user_sender_id+'/'+chat.user_receiver_id);
  }
  public saveMessages(chat:Chat,message:Messages):Observable<Chat[]>{
    return this.http.post<Chat[]>(this.userUrl1+chat.user_sender_id+'/'+chat.user_receiver_id,message);
  }
  public getMessagesRec(chat:Chat):Observable<Messages[]>{
    
    return this.http.get<Messages[]>(this.userUrl+chat.user_receiver_id+'/'+chat.user_sender_id);
  }
  
}
