/* import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'pm-images',
  templateUrl: './images.component.html',
  styleUrls: ['./images.component.css']
})
export class ImagesComponent implements OnInit {

  public pageTitle: string = 'images';

  constructor() { }

  ngOnInit() {
  }

}
 */

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'pm-images',
  templateUrl: './images.component.html',
  styleUrls: ['./images.component.css']
})
export class ImagesComponent implements OnInit {

  public pageTitle: string = 'images';

  constructor() { }

  ngOnInit() {

  }

}
