/* import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'pm-album',
  templateUrl: './album.component.html',
  styleUrls: ['./album.component.css']
})
export class AlbumComponent implements OnInit {
  
  public pageTitle: string = 'album';

  constructor() { }

  ngOnInit() {
  }

} */

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'pm-album',
  templateUrl: './album.component.html',
  styleUrls: ['./album.component.css']
})
export class AlbumComponent implements OnInit {

  public pageTitle: string = 'album';

  constructor() { }

  toggleImage(): void {
  }

  ngOnInit() {
  }

  textAreasList: any = [];
  addTextarea() {
    this.textAreasList.push('text_area' + (this.textAreasList.length + 1));
  }
}




