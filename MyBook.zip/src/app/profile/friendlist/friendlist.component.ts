import { Component, OnInit } from '@angular/core';
import { FriendlistService } from '../../service/friendlist.service';


@Component({
  selector: 'app-friendlist',
  templateUrl: './friendlist.component.html',
  styleUrls: ['./friendlist.component.css']
})
export class FriendlistComponent implements OnInit {

  public pageTitle: string = 'friendlist';


  friends: string[]=[]

  constructor(private friendlistService: FriendlistService) { }

  ngOnInit() {
    this.getList();
    
  }

  getList(): void {
    this.friendlistService.getList().subscribe(friends => {
      this.friends = friends
    })
  }
 /*  onSubmit():void{
    this.getList();
  }
   */

}
