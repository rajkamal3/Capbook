import { Component, OnInit } from '@angular/core';
import { Profileaboutme } from '../profileaboutme';
import { ProfileService } from './profile.service';

@Component({
  selector: 'pm-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {

  profile:Profileaboutme[]=[]
  public pageTitle: string = 'profile';

  constructor(private service:ProfileService) { }

  ngOnInit() {
    this.getUsers();
  }

  getUsers():void{
    this.service.getUsers().subscribe(profiles=>{this.profile=profiles})

  }
}
