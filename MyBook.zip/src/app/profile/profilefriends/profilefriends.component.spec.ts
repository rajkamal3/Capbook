import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProfilefriendsComponent } from './profilefriends.component';

describe('ProfilefriendsComponent', () => {
  let component: ProfilefriendsComponent;
  let fixture: ComponentFixture<ProfilefriendsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProfilefriendsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProfilefriendsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
