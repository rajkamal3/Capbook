import { Component, OnInit } from '@angular/core';
import { OnlineService } from '../../online/online.service';
import { Request } from "../../request";


@Component({
  selector: 'pm-profilefriends',
  templateUrl: './profilefriends.component.html',
  styleUrls: ['./profilefriends.component.css']
})
export class ProfilefriendsComponent implements OnInit {

  public pageTitle: string = 'friends';

  errorMessage:string;
  online: Request[]=[];
  constructor(private onlineService: OnlineService) { }

  ngOnInit(): void {
    this.onlineService.getUsers()
    .subscribe(request =>{
      this.online= request;
    },
    error => this.errorMessage = <any>error );
  }

}
