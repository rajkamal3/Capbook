import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'pm-profilephotos',
  templateUrl: './profilephotos.component.html',
  styleUrls: ['./profilephotos.component.css']
})
export class ProfilephotosComponent implements OnInit {

  public pageTitle: string = 'photos';

  constructor() { }

  ngOnInit() {
  }

}
