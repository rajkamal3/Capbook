import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProfilephotosComponent } from './profilephotos.component';

describe('ProfilephotosComponent', () => {
  let component: ProfilephotosComponent;
  let fixture: ComponentFixture<ProfilephotosComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProfilephotosComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProfilephotosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
