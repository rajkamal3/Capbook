import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'pm-profilewall',
  templateUrl: './profilewall.component.html',
  styleUrls: ['./profilewall.component.css']
})
export class ProfilewallComponent implements OnInit {

  public pageTitle: string = 'mywall';

  constructor() { }

  ngOnInit() {
  }

}
