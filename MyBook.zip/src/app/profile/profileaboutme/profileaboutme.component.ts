import { Component, OnInit } from '@angular/core';
import { ProfileaboutmeService } from './profileaboutme.service';
import { Profileaboutme } from '../../profileaboutme';

@Component({
  selector: 'pm-profileaboutme',
  templateUrl: './profileaboutme.component.html',
  styleUrls: ['./profileaboutme.component.css']
})
export class ProfileaboutmeComponent implements OnInit {

  aboutme : Profileaboutme[]=[]

  public pageTitle: string = 'aboutme';

  constructor(private service: ProfileaboutmeService) { }

  ngOnInit() {
    this.getUsers();
  }

  getUsers(): void{
    this.service.getUsers().subscribe(profile=>{this.aboutme=profile})
  }
}
