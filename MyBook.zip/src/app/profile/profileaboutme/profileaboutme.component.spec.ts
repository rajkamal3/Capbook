import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProfileaboutmeComponent } from './profileaboutme.component';

describe('ProfileaboutmeComponent', () => {
  let component: ProfileaboutmeComponent;
  let fixture: ComponentFixture<ProfileaboutmeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProfileaboutmeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProfileaboutmeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
