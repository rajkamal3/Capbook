import { Injectable } from "../../../../node_modules/@angular/core";
import { HttpClient, HttpErrorResponse } from "@angular/common/http";
import { Observable } from '../../../../node_modules/rxjs';
import { Profileaboutme } from '../../profileaboutme';

@Injectable()
export class ProfileaboutmeService {
    private userUrl: string = "http://localhost:8083/api/aboutme/102";
    constructor(private http: HttpClient) { }
    getUsers(): Observable<Profileaboutme[]> {
        return this.http.get<Profileaboutme[]>(this.userUrl)
        //.do(data => console.log('All: '+JSON.stringify(data)));
        
    }
    private handleError(err: HttpErrorResponse) {
        // console.error(err.message);
        return Observable.throw(err.message);
    }
}
