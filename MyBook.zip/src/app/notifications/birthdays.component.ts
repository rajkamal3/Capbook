import { Component, OnInit } from '@angular/core';
import { ILatlang } from '../../api/latlang/latlang';
import { LatService } from '../../api/latlang/latlang.service';
/* import { ILatlang } from '../../api/latlang/latlang';
import { LatService } from '../../api/latlang/latlang.service'; */

@Component({
  selector: 'pm-birthdays',
  templateUrl: './birthdays.component.html',
  styleUrls: ['./birthdays.component.css']
})
export class BirthdaysComponent implements OnInit {

  /* public pageTitle: string = 'birthdays';

  constructor() { }

  ngOnInit() {
    
  } */

  public pageTitle: string = 'notifications';

  latlangs: ILatlang[] = [];

  _listFilter: string;
  errorMessage: string;
  constructor(private _latService: LatService) {
  }

  ngOnInit(): void {
    this._latService.getdetails().subscribe(latlangs => {
      this.latlangs = latlangs;
    },
      error => this.errorMessage = <any>error
    );

  }

}
