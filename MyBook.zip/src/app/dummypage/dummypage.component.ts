import { Component, OnInit } from '@angular/core';
import { UserProfile } from '../loginpage/userprofile';
import { Router } from '../../../node_modules/@angular/router';

@Component({
  selector: 'pm-dummypage',
  templateUrl: './dummypage.component.html',
  styleUrls: ['./dummypage.component.css']
})
export class DummypageComponent implements OnInit {
user:UserProfile=new UserProfile();
  public pageTitle : string ='dummy';
  name=localStorage.getItem('username');
  id=localStorage.getItem('userid');
  constructor(private router:Router) {
  
   }
  
logOut(){
  localStorage.clear();
this.router.navigate(["/HomePage"])
//window.location.reload();
}
  ngOnInit() {

  }

}
