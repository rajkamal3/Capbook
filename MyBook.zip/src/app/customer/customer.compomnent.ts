import { ICustomer } from "../../api/customer/customer";
import { Component, OnInit } from "@angular/core";
import { CustomerService } from "../../api/customer/customer.service";
import { RegistrationComponent } from "../registration/registration component";

@Component({
    selector:'pm-customer',
     templateUrl:'./customer.component.html',
    // styles:['thead{color:#337AB7;}']
     
 })
 export class CustomerComponent implements OnInit{
     pageTitle:string='Customers';
     customers:ICustomer[]=[];
     _listFilter:string;
    filteredCustomers:ICustomer[];
     errorMessage:string;
     constructor(private _customerService:CustomerService,private registrationComponent:RegistrationComponent)
     {
          this._listFilter='a'
     }
 
  ngOnInit():void{
      // console.log('In OnInit')
      this._customerService.getProducts().subscribe(customers=> {
          this.customers=customers;
          this.filteredCustomers=this.customers;
         
          
      },
      error=>this.errorMessage=<any>error
      );
     
      
  }
  editCustomers(customer:ICustomer): void{
    this.registrationComponent.customer=Object.assign({},customer) ;
    this.registrationComponent.butlabel='Update'
   this.registrationComponent.flag=true

}
  deleteCustomers(customerId:number): void{
      this._customerService.deleteCustomers(customerId).subscribe(customers=>console.log(customers))
  }
  get listFilter():string {
    return this._listFilter;

}
set listFilter(value:string)
{
    this._listFilter=value;
    this.filteredCustomers=this.listFilter?this.performFilter(this.listFilter):this.customers;
}


performFilter(filterBy:string): ICustomer[]
{
    filterBy=filterBy.toLocaleLowerCase();
    return this.customers.filter((customer:ICustomer)=>
    customer.firstName.toLocaleLowerCase().indexOf(filterBy)!==-1
    );
}

 }