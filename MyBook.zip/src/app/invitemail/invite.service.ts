//import { HttpClient  } from '../../node_modules/@types/selenium-webdriver/http';
import { Injectable } from "@angular/core";

import { Observable } from "rxjs";

import { HttpErrorResponse, HttpHeaders,HttpRequest,HttpEvent, HttpClient } from "@angular/common/http";


/* import { Injectable } from '@angular/core';
import { IComment } from './comment';
import { HttpClient } from "@angular/common/http";
import { Observable } from '../../node_modules/rxjs';



@Injectable({
providedIn: 'root'
})
export class CommentService {
private _productUrl='http://localhost:8085/api ';

private comment:IComment;
c:IComment;
constructor(private _http:HttpClient){

}
getComments():Observable<IComment[]>{
return this._http.get<IComment[]>(this._productUrl)
} 
createcomment(comments:IComment):Observable <IComment>
{
return this._http.post<IComment>(this._productUrl,comments,{})
}

} 
 
 */

const httpOptions ={
    headers :new HttpHeaders({'Content-Type':'application/json'})
    };     
@Injectable()
export class InviteService{
    private inviteuser='http://localhost:8088/request/';
    private _inviteUrl;
    userId:number=101;
    constructor(private _http:HttpClient){
    }
  inviteUser(email:string):Observable<string>{

    this._inviteUrl=this.inviteuser+email+"/"+this.userId;
    alert(email);
    return this._http.get<string>(this._inviteUrl);
        }
        // addFriends(addrequest:friend):Observable<friend>{
        //     alert("inservice")
        //     this._friendUrl=this._addFrd+'api'+'/'+'request';
        //     return this._http.post<friend>(this._friendUrl,addrequest);
        //     }  

  }


