import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from '../../../node_modules/rxjs';
import { Groups } from './groups';

const httpOptions ={
  headers :new HttpHeaders({'Content-Type':'application/json'})
};

@Injectable()
export class GroupsServiceImpl {

  
  private _friendUrl='http://localhost:8083/groups';
  private _getGroupNames='http://localhost:8083/groups/names';
  _Url:string='http://localhost:8083/groups';

  private search:string='names';
  public static groups :Groups;


  constructor(private http: HttpClient) { }

  getGroups():Observable<Groups[]>{
    return  this.http.get<Groups[]>(this._getGroupNames)
    
   
}

  getGroupsByName(groupName: string): Observable<any> {

    this._friendUrl=this._Url+'/'+this.search+'/'+groupName;
    return  this.http.get<Groups[]>(this._friendUrl)
    }
   
}
