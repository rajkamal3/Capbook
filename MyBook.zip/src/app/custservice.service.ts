import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

import { IBirthday } from './bdayy';



const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable()

export class CustserviceService {

  private custUrl: string = 'http://localhost:8088/api/birthdatesrec';

  private custUrl1: string = 'http://localhost:8088/api/birthdatessen';
  private url: string;
  private url1: string;

  constructor(private http: HttpClient) { }

  getDetails(userId: number): Observable<IBirthday[]> {
    this.url = this.custUrl + '/' + userId;
    //console.log('Customers here!' + this.http.get<Customer[]>(this.url))
    return this.http.get<IBirthday[]>(this.url)
  }
  getDetails1(userId: number): Observable<IBirthday[]> {
    this.url1 = this.custUrl1 + '/' + userId;
    // console.log('Customers here!' + this.http.get<Customer[]>(this.url1))
    return this.http.get<IBirthday[]>(this.url1)
  }
  /* deleteCustomers(customerId:number): Observable<Customer[]>{
  this.url=this.custUrl+'/'+customerId
    return this.http.delete<Customer[]>(this.url)
  
  } */

}
