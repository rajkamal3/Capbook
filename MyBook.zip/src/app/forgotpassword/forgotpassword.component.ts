import { Component, OnInit } from '@angular/core';
import { Email } from './email';
import { frgtService } from './forgotpassword.service';
import { Login } from '../loginpage/login';
import { Router } from '../../../node_modules/@angular/router';

@Component({
  // selector: 'pm-forgotpassword',
  templateUrl: './forgotpassword.component.html',
  styleUrls: ['./forgotpassword.component.css']
})
export class ForgotpasswordComponent implements OnInit {

  public pageTitle : string ='forgotpwd';
  email:string;
  login: Login[];
 
  constructor(private forgtservice:frgtService,private router:Router) { }

  ngOnInit() {
  }
  saveAddr():void{
    alert('email:'+this.email)
    this.postAddr()
this.router.navigate(["/HomePage"])
  }

  postAddr():void{
   
    this.forgtservice.postMail(this.email).subscribe(email=>this.email)
  }
}
