export interface Request{
    userName: string;
	status: string;
}