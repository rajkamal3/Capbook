/* import { Component, OnInit } from '@angular/core';
import { RequestService } from "./request.service";
import { Request } from "../request";

@Component({
  selector: 'app-request',
  templateUrl: './request.component.html',
  styleUrls: ['./request.component.css']
})
export class RequestComponent implements OnInit {
  errorMessage:string;
  requests: Request[]=[];
  constructor(private requestService: RequestService) { }

  ngOnInit(): void {
    this.requestService.getUsers()
    .subscribe(request =>{
      this.requests= request;
    },
    error => this.errorMessage = <any>error );
  }

}
 */

import { Component, OnInit } from '@angular/core';
import { RequestService } from "./request.service";
import { Request } from "../request";

@Component({
  selector: 'app-request',
  templateUrl: './request.component.html',
  styleUrls: ['./request.component.css']
})
export class RequestComponent implements OnInit {
  errorMessage: string;
  flag: boolean = true;
  requests: string[] = [];
  userid: number = 102;
  constructor(private requestService: RequestService) { }

  ngOnInit(): void {
    /* this.requestService.getUsers()
    .subscribe(request =>{
      this.requests= request;
    },
    error => this.errorMessage = <any>error );
    console.log(this.requests) */
  //  this.userid = JSON.parse(localStorage.getItem('userId'))
    this.getUser();
  }

  getUser(): void {
    this.requestService.getUsers()
      .subscribe(request => {
        this.requests = request;
      })
    console.log(this.requests)

  }

  accept(request: string): void {
    status = 'Accept'
    this.requestService.acceptUsers(request, status)
      .subscribe();
    location.reload();
    //this.flag=false;
  }

  reject(request: string): void {
    status = 'Reject'
    this.requestService.rejectUsers(request, status)
      .subscribe();
    location.reload();
    // this.flag=false;
  }



}
