export interface Profileaboutme {
    userId: number;
    userName: string;
	//private Address address;
	isPrivateDob: boolean;
	dob: Date;
	isPrivateAreaofIntrest: boolean;
	areaofInterest: string;
	
	//private List<Albums> albums=new ArrayList<Albums>();
	isPrivategender: boolean;
	gender: string;
	mobileNo: number;
	isPrivateMobileNo: boolean;

	//private List<Groups> groups;
	
	
	//private List<Status> status;
	
	email:string;
	isPrivateEmail: boolean;
	
}