import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'pm-feedflow',
  templateUrl: './feedflow.component.html',
  styleUrls: ['./feedflow.component.css']
})
export class FeedflowComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
