import { Component, OnInit } from '@angular/core';
import { OnlineService } from './online.service';
import { Request } from "../request";
import { User } from '../user';
import { Router } from '@angular/router';

@Component({
  selector: 'app-online',
  templateUrl: './online.component.html',
  styleUrls: ['./online.component.css']
})
export class OnlineComponent implements OnInit {

  errorMessage: string;
  online: User[];
  constructor(private onlineService: OnlineService, private router: Router) { }

  ngOnInit(): void {
    this.onlineService.getUsers()
      .subscribe(request => {
        this.online = request
      },
        error => this.errorMessage = <any>error);

  }
  getReceiverId(id: number) {
    localStorage.setItem('receiverId', JSON.stringify(id));
  }
}