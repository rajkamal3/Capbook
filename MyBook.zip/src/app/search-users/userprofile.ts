export class UserProfile {
    userId: number;
    userName: string;
    dob: Date;
    gender: string;
    areaofInterest: string;
    
}