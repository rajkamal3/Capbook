import { Component, OnInit } from "@angular/core";
import { LatService } from "../../api/latlang/latlang.service";
import { ILatlang } from "../../api/latlang/latlang";


@Component({
    selector: 'cap-maps',
    templateUrl: './maps.component.html',
    styleUrls: ['./maps.component.css']
})
export class MapsComponent implements OnInit {

    latlangs: ILatlang[] = [];

    _listFilter: string;
    errorMessage: string;
    constructor(private _latService: LatService) {
    }

    ngOnInit(): void {
        this._latService.getdetails().subscribe(latlangs => {
            this.latlangs = latlangs;
        },
            error => this.errorMessage = <any>error
        );

    }

}


