export interface User{
    userName: string;
    imageUrl: string;
    userId: number;
    address: any;
    isPrivateDob: boolean;
    dob: Date;
    isPrivateAreaofIntrest: boolean;
    areaofInterest: string;
    albums: any;
    isPrivategender: boolean;
    gender: string;
    mobileNo: number;
    isPrivateMobileN: boolean;
    groups: any;
    
    status: any;
    
    chat: any;
    email: string;
    isPrivateEmail: boolean;
    } 
     
    