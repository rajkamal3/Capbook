export class friend{
    requestId:number;
    senderId:number;
    receiverId:number;
    status:string;
}