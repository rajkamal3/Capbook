import { Component, OnInit } from '@angular/core';


import { AddFriendservice } from './addfriend.service';
import { UserProfile } from './userprofile';
import { friend } from './friend';



@Component({
  selector: 'app-addfriend',
  templateUrl: './addfriend.component.html',
  styleUrls: ['./addfriend.component.css']
})
export class AddFriendComponent implements OnInit {

reqBtn:boolean=false;
  button:string="Add Friend";
  senId:friend;
profiles: UserProfile;
frnd=new friend();
  frndReq=new friend();
  toggleReqbtn(){
    this.reqBtn=!this.reqBtn;
  }
 addFriends():void{
  if(this.reqBtn==true){
  this._pservice.addFriends(this.frnd).subscribe(frndReq=>{console.log(frndReq);
  this.frndReq=frndReq;
  
  alert(this.frndReq.requestId);
  });

  
  }
  else{
   
    this._pservice.deletereq(this.frndReq.requestId).subscribe();
  }
 
  } 
  getReceiverId(receiverId:number){
  this.frnd.receiverId=receiverId;
 this.frnd.senderId=JSON.parse(localStorage.getItem('userId'));

   }

  constructor(private _pservice:AddFriendservice) { this.getProfileList()}

  ngOnInit() {
    
  }
getProfileList():void{
  this._pservice.getProfile('saisruthi').subscribe(profile=>this.profiles=profile);
}




}
