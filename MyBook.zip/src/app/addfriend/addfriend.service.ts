import { Injectable } from "@angular/core";

import { HttpClient, HttpErrorResponse, HttpHeaders } from "@angular/common/http";
import { Observable } from "rxjs/Observable";
import "rxjs/add/observable/throw";
import "rxjs/add/operator/do";
import "rxjs/add/operator/catch";
import { friend } from "./friend";
import { UserProfile } from "./userprofile";


const httpOptions ={
headers :new HttpHeaders({'Content-Type':'application/json'})
};
@Injectable()
export class AddFriendservice{
private _friendUrl='http://localhost:8083/api/request';
private  getprofileurl='http://localhost:8083/profileCreation/profile/';

private friendId:number;

constructor(private _http:HttpClient){

}
 


addFriends(addrequest:friend):Observable<friend>{
    
 
    return this._http.post<friend>(this._friendUrl,addrequest);
    } 
 
getProfile(userName:string):Observable<UserProfile>{
   
    return this._http.get<UserProfile>(this.getprofileurl+userName);
}

deletereq(deleterequestId:number):Observable<friend>{
    
    return this._http.delete<friend>(this._friendUrl+'/'+deleterequestId);
}

}