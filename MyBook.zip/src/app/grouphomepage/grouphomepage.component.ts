import { Component, OnInit } from '@angular/core';
import { IGroup, IPostT, User } from '../../api/groups/groups';
import { IFriends, GroupTopic, GroupComments } from '../../api/group-profile/friends';
import { GroupsService } from '../../api/groups/groups.service';
import { group_request } from '../../api/group-profile/friends';
import { GroupProfileService } from '../../api/group-profile/group-profile.service';
import { GroupsServiceImpl } from '../search-groups/groups.service';
@Component({
  selector: 'pm-group-profile',
  templateUrl: './grouphomepage.component.html',
  styleUrls: ['./grouphomepage.component.css']
})
export class GrouphomepageComponent implements OnInit {

  public pageTitle: string = 'groupHomeProfile';
  group: IGroup = new IGroup();
  groupComments: GroupComments[] = [];

  public groupNme: string;
  public groupId: number;
  postT: IPostT = new IPostT();
  gtopic: GroupTopic = new GroupTopic();
  dontPostT: IPostT = new IPostT();
  topic: GroupTopic[] = [];
  errorMessage: string;
  members: boolean = false;
  groupJoin: boolean = false;
  groupTopic: GroupTopic = new GroupTopic();
  gComments: GroupComments = new GroupComments();
  gAllComments: GroupComments[] = [];
  static userId;
  static i:number=0;



  gmembers: group_request[] = [];
  groups: IGroup = new IGroup();
  _postPhoto: boolean = false;
  _postTopic: boolean = false;
  message: string;
  dummyGroupId: number;
  addRequest: group_request = new group_request();
  user: User = new User();
  commented_by_user:User;
userId:number;
  constructor(private _groupService: GroupsService, private _groupProfileService: GroupProfileService) {

  }

  ngOnInit() {
    console.log("in profile oninit")


    this.userId = JSON.parse(localStorage.getItem('userId'))





   // this.group = JSON.parse(localStorage.getItem('groupInfo'));

    this.groupNme = GroupsService.groups.groupName;
    this.groupId = GroupsService.groups.groupId;
    console.log(this.group)
    this.addRequest.groupId =  this.groupId ;
    this.addRequest.userId = this.userId;
    this.addRequest.status = "pending";
    this.groupTopic.topic_started_by = this.userId;
    this.groupTopic.group_id =  this.groupId ;

    console.log("end of profile compo")
    this.getUserDetails(this.addRequest.userId);



    /* this._groupProfileService.getFriends(this.groupId).subscribe(gmembers => {
    this.gmembers = gmembers;

    },
      error => this.errorMessage = <any>error
    ); */
  }
 
  deleteFriends(userId: number) {
    userId=this.userId;
    this._groupProfileService.deleteFriends(userId).subscribe(gmembers => {
    this.gmembers = gmembers;

    },
      error => this.errorMessage = <any>error
    );
  }

  showTopic() {
    this._postTopic = false;
    this._postPhoto = true;
  }
  postTopic(): void {
    this._postTopic = true;
    this._postPhoto = false;

  }
  /* afterPost():void{
    this._postPhoto=false;
    this._postTopic=false;
    console.log(this.group.groupId)

this.postT.groupId=this.group.groupId;
console.log(this.postT)
    this._groupService.postT(this.postT).subscribe(topic=>{console.log("receiving empty array in after post");console.log(topic);this.topic=topic;},
 
      error=>this.errorMessage=<any>error);
    
    
    } */
  afterPost1(): void {
    this._postPhoto = false;
    this._postTopic = false;
    console.log( this.groupId )
    this.gtopic.topic_started_by = this.user.userId;

    this.gtopic.group_id =  this.groupId ;
    console.log(this.gtopic)
    this._groupService.postT(this.gtopic).subscribe(topic => { console.log("receiving empty array in after post"); console.log(topic); this.topic = topic; },

      error => this.errorMessage = <any>error);


  }
  flag: boolean = false;
  flag1: boolean = false;
  flag2: boolean = false;
  onClick1(): void {
    this.flag2 = true;
  }


  onClic(): void {
    this.flag = true;
  }

  toggleImage(): void {

    this.groupJoin = !this.groupJoin
  }
  toggleImage1(): void {
    this.members = !this.members
  }
  addFriends() {


    this._groupProfileService.addFriends(this.addRequest).subscribe(groupRequests => console.log(groupRequests))

  }
  getComments(topics: GroupTopic) {
    this._groupService.getComments(topics).subscribe(groupComments => {
      console.log(groupComments);
      this.groupComments = groupComments;

    })
  }
  comment(text: string, topic: GroupTopic) {
    this.addRequest.userId = this.userId;
    this.gComments.topicId = topic;
    this.commented_by_user=this.getUserDetails(this.addRequest.userId);
    this.gComments.commented_by = this.commented_by_user.userName;
    console.log("***************************")
    console.log(this.addRequest.userId)
    this.gComments.postedDate;
    this._groupProfileService.postComment(this.gComments).subscribe(gAllComments => {

      console.log(gAllComments);
      this.gAllComments = gAllComments;
      
        
      });   

  }

  getUserDetails(userId:number):User {
    this._groupService.getUserDetails(userId).subscribe(users => {
      console.log(this.user);
      console.log("********");
      console.log(this.addRequest.userId);

      console.log("********");
      this.user = users;
      console.log(this.user);
    })
    return this.user;
  }
}

