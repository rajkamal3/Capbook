import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GroupProfileSearchComponent } from './group-profile.component';

describe('GroupProfileSearchComponent', () => {
  let component: GroupProfileSearchComponent;
  let fixture: ComponentFixture<GroupProfileSearchComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GroupProfileSearchComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GroupProfileSearchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
