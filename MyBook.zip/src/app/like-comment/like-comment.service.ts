import { Injectable } from '@angular/core';

import { IComments } from '../showposts/comments';
import { HttpClient, HttpErrorResponse, HttpHeaders,HttpRequest,HttpEvent } from "@angular/common/http";
import { Observable } from "rxjs";
import { Likes } from '../showposts/Likes';

@Injectable()
export class LikeCommentService {
  private url='http://localhost:8087/comments/';
  private url1='http://localhost:8087/likes/';
  private url2='http://localhost:8087/dislikes/';
  private url3='http://localhost:8087/comments';
  private url4='http://localhost:8087/comment';

  constructor(private http:HttpClient) { }

  public getComments(status_id:number){
    return this.http.get<IComments[]>(this.url+status_id);
  }
  public addComments(status_id:number,comments:IComments){
    return this.http.post<IComments>(this.url+status_id,comments);
  }
  public updateLikeCount(status_id:number,like:Likes){
    return this.http.post<Likes>(this.url1+status_id,like);
  }
  public updateDislikeCount(status_id:number,like:Likes){
    return this.http.post<Likes>(this.url2+status_id,like);
  }
  public getLikeCount(status_id:number){
    return this.http.get<number>(this.url1+status_id);
  }
  public getDislikeCount(status_id:number){
    return this.http.get<number>(this.url2+status_id);
  }

  
commentLikeIncre(status_id:number,commentId:number){
return this.http.put<number>(this.url3+'/'+status_id+'/'+commentId,{})
} 
commentDislikeIncre(status_id:number,commentId:number){
  return this.http.put<number>(this.url4+'/'+status_id+'/'+commentId,{})
  } 
 


}
