import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GroupshomeComponent } from './groupshome.component';

describe('GroupshomeComponent', () => {
  let component: GroupshomeComponent;
  let fixture: ComponentFixture<GroupshomeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GroupshomeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GroupshomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
