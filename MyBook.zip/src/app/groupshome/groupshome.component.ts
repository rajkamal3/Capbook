import { Component, OnInit } from '@angular/core';
import { IGroup, IGroup1 ,IGroup2} from '../../api/groups/groups';
import { GroupsService } from '../../api/groups/groups.service';
import { GroupsServiceAdmin } from '../../api/groupsAdmin/groups.service';
import { TopicService } from '../../api/topics/topics.service';

@Component({
  selector: 'pm-groupshome',
  templateUrl: './groupshome.component.html',
  styleUrls: ['./groupshome.component.css']
})
export class GroupshomeComponent implements OnInit {
  public pageTitle: string='groupshome';
  groupsOfUser:IGroup1[]=[];
  joinedGroups:IGroup2[]=[];
  errorMessage:string;
  userId:number;
 // groupAdmin:number=102;
  constructor(private _groupService:GroupsService) { }

  ngOnInit() {
this.userId = JSON.parse(localStorage.getItem('userId'))
    this._groupService.getGroups(this.userId).subscribe(groupsOfUser=> {
      this.groupsOfUser=groupsOfUser;
      console.log(groupsOfUser)
    
      this._groupService.getJoinedGroups(this.userId).subscribe(joinedGroups=>{
       this.joinedGroups=joinedGroups; 
       console.log(joinedGroups)
      })
},

error=>this.errorMessage=<any>error
    );
  }
  getGroups(groupAdmin:number){
    this._groupService.getGroups(groupAdmin);
  }

getJoindGroups(groupId:number){
  this._groupService.getJoinedGroups(groupId);
}

groupPage(friendlist:IGroup){
  GroupsService.groups=friendlist;
}
}
