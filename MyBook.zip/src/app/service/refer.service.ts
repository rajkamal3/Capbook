import { Injectable } from '@angular/core';
import { HttpClient } from '../../../node_modules/@angular/common/http';
import { Observable } from '../../../node_modules/rxjs';

@Injectable()

export class ReferService {

  private Url:string="http://localhost:8088/api/request/101";
  constructor(private http:HttpClient) { }

  // this.Url=this.url+userid;
getList():Observable<string[]>{
  return this.http.get<string[]>(this.Url)
}


}
