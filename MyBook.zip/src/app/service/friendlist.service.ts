import { Injectable } from '@angular/core';
import { HttpClient } from '../../../node_modules/@angular/common/http';
import { Observable } from '../../../node_modules/rxjs';

@Injectable()

export class FriendlistService {

  private Url:string="http://localhost:8083/api/list/102";

  constructor(private http: HttpClient) { }

  getList():Observable<string[]>  {
    return this.http.get<string[]>(this.Url)

  }
}
