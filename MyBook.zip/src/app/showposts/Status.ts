import { UserProfile } from './UserProfile';
import { IComments } from './comments';

export class IShowPosts {
    status_id:number;
    statusText:string;
    userName:string;
    comments:IComments;
    user:UserProfile;
   
    }

