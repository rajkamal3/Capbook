import { Component, OnInit } from '@angular/core';

import { IShowPosts } from './Status';
import { StatusService } from '../../api/customer/showposts.service';
import { UserProfile } from './UserProfile';
import { HttpClient, HttpResponse, HttpEventType } from '@angular/common/http';
import { LikeCommentService } from '../like-comment/like-comment.service';
import { IComments } from './comments';
import { Likes } from './Likes';
import { NgIf } from '../../../node_modules/@angular/common';


@Component({
  selector: 'pm-showposts',
  templateUrl: './showposts.component.html',
  styleUrls: ['./showposts.component.css']
})
export class ShowpostsComponent implements OnInit {

  //selectedFile: File=null;
  statusText: string;
  showposts: IShowPosts[] = [];
  status: IShowPosts = new IShowPosts();
  user: UserProfile[];
  userId: number;
  input: any;

  selectedFiles: FileList
  // currentFileUpload: File




  constructor(private service: StatusService, private likecommentservice: LikeCommentService) {

  }

  /********************************************************************************************
   *  On loading user profile page all his Posts will appear on his wall along with post 
   * comments and likes and dis-likes
   ********************************************************************************************/

  ngOnInit() {
    this.userId=JSON.parse(localStorage.getItem('userId'));
    this.getStatus(this.userId);
    this.like.liked_By=this.userId;
    this.comments.postedBy=this.userId;
    

    
  }

  getStatus(userId: Number) {
    this.service.getStatus(this.userId).subscribe(showposts => { this.showposts = showposts; console.log(showposts); })
    console.log(this.showposts);
  }


  upload() {

    this.service.pushFileToStorage(this.userId,this.status).subscribe(status => this.status)

    location.reload();

  }

  deleteStatus(status_id: Number): void {
    this.service.deleteStatus(status_id).subscribe();
    location.reload();
  }


  displayTextbox: boolean = false;
  displayComments: IComments[];
  comments: IComments = new IComments();

  like: Likes = new Likes;
  likeCount: number;
  disLikeCount: number;




  displayTextArea() {
    this.displayTextbox = true;
  }

  commentLikeIncre(status_id:number,commentId: number) {
    this.likecommentservice.commentLikeIncre(this.status.status_id, commentId).subscribe();
    location.reload();
  }
  commentDislikeIncre(status_id:number,commentId: number) {
    this.likecommentservice.commentDislikeIncre(this.status.status_id, commentId).subscribe();
    location.reload();
  }


  getComments(status_id: number) {
    this.likecommentservice.getLikeCount(status_id).subscribe(like => {
      this.likeCount = like;

      this.likecommentservice.getDislikeCount(status_id).subscribe(data => {
        this.disLikeCount = data;

      })
    })

    this.likecommentservice.getComments(status_id).subscribe(data => {
      this.displayComments = data;

    });
  };
  addComments(status_id: number) {
    this.likecommentservice.addComments(status_id, this.comments).subscribe(data => {
      location.reload();
    });
  };

  updateLikeCount(status_id: number) {
    this.likecommentservice.updateLikeCount(status_id, this.like).subscribe(data => { });
    location.reload();
  };
  updateDislikeCount(status_id: number) {
    this.likecommentservice.updateDislikeCount(status_id, this.like).subscribe(data => { });
    location.reload();
  };


}





