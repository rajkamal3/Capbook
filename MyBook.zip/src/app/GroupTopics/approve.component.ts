import { Component, OnInit } from '@angular/core';
import { IGrequests } from '../../api/groupsAdmin/grequests';
import { ApproveService } from '../../api/groupsAdmin/approve.service';


@Component({
  selector: 'app-approve',
  templateUrl: './approve.component.html',
  // styleUrls: ['./approve.component.css']
})
export class ApproveComponent implements OnInit {

  
  approve: IGrequests[];
  
  // fname:string='tom';
  constructor(private apprveserv:ApproveService) { }

  ngOnInit() {
    this.getApproveReq();
  }

  getApproveReq():void{
    console.log("in  ")
    this.apprveserv.getApprove()
      .subscribe(approve=> this.approve=approve )

    console.log(this.approve)  
  }
  accept(approve1 :IGrequests) :void{
    approve1.status='accept'
    this.apprveserv.update(approve1).subscribe(approve=>console.log('approved'))
  }
  reject(approve1 :IGrequests) :void{
    approve1.status='rejected'
    this.apprveserv.update(approve1).subscribe(approve=>console.log('rejected'))
  }

}
