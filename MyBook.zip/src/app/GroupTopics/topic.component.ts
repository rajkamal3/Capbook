import { ITopic } from "../../api/topics/topics";
import { Component, OnInit } from "@angular/core";
import { TopicService } from "../../api/topics/topics.service";


@Component({
    selector:'pm-topic',
     templateUrl:'./topic.component.html',
    styles:['thead{color:#337AB7;}']
     
 })
 export class TopicComponent implements OnInit{
     pageTitle:string='Topics';
     topics:ITopic[]=[];
    
     errorMessage:string;
     constructor(private _topicService:TopicService)
     {
          
     }
    
 
  ngOnInit():void{
      console.log('In OnInit')
    this._topicService.getTopics().subscribe(topics=> {
         this.topics=topics;       
          
      },
       error=>this.errorMessage=<any>error
      );
     
      
  }

  deleteTopics(groupId:number,topicId:number):void{
    this._topicService.deleteTopics(groupId,topicId).subscribe(topics=>console.log(topics))
  }
 

}
 

 