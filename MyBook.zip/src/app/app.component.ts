import { Component } from '@angular/core';
import { LatService } from '../api/latlang/latlang.service';
import { ILatlang } from '../api/latlang/latlang';

@Component({
  selector: 'pm-root',
  templateUrl: './app.component.html',
})

export class AppComponent {
  title: string = 'Google Maps';

  latlangs: ILatlang[] = [];

  _listFilter: string;
  errorMessage: string;
  constructor(private _latService: LatService) {
  }

  ngOnInit(): void {
    this._latService.getdetails().subscribe(latlangs => {
      this.latlangs = latlangs;
    },
      error => this.errorMessage = <any>error
    );

  }
}
