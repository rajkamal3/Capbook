import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'pm-next-page',
  templateUrl: './next-page.component.html',
  styleUrls: ['./next-page.component.css']
})
export class NextPageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
