
import { Component, OnInit } from "@angular/core";

import { ISms } from './sms';

import { SmsService } from './sms.service';


@Component({
    /*  selector:'pm-email', */
    templateUrl: './sms.component.html',
    styles: ['thead{color:#337AB7;}']

})
export class SmsComponent implements OnInit {
    pageTitle: string = 'sms';
    sms: ISms[] = [];

    errorMessage: string;
    constructor(private _smsService: SmsService) {

    }


    ngOnInit(): void {
        // console.log('In OnInit')
        this._smsService.getSms().subscribe(sms => {
            this.sms = sms;



        },
            error => this.errorMessage = <any>error
        );


    }


}


