import { Injectable } from "@angular/core";

import { HttpClient, HttpErrorResponse } from "@angular/common/http";
import { Observable } from "../../../node_modules/rxjs";
import { ISms } from './sms';


@Injectable()
export class SmsService{
    private _smsUrl='http://localhost:8087/api/getMsgs/102';
    
    constructor(private _http:HttpClient){

    }
    getSms():Observable<ISms[]>{
        return  this._http.get<ISms[]>(this._smsUrl)
    }
    private handleError(err:HttpErrorResponse){
        console.error(err.message)
        return Observable.throw(err.message)
    }
    
    
}