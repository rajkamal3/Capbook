export interface ISms{

    msgId:number;
    receivedDate:Date;
    mobileNumber:number;
    msgBody:String;
    userName:string;
    
}