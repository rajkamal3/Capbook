import { Injectable } from "@angular/core";

import { HttpClient, HttpErrorResponse } from "@angular/common/http";
import { Observable } from "../../../node_modules/rxjs";
import { ITextEmail } from './email';


@Injectable()
export class EmailService{
    private _emailUrl='http://localhost:8087/api/getEmails/101';
    
    constructor(private _http:HttpClient){

    }
    getEmails():Observable<ITextEmail[]>{
        return  this._http.get<ITextEmail[]>(this._emailUrl)
    }
    private handleError(err:HttpErrorResponse){
        console.error(err.message)
        return Observable.throw(err.message)
    }
    
    
}