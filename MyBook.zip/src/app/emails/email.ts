export interface ITextEmail{

    id:number;
    date:Date;
    fromAddress:string;
    messageBody:String;
    subject:string;
    toAddress:string;
}