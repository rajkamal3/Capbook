
import { Component, OnInit } from "@angular/core";

import { ITextEmail } from './email';
import { EmailService } from './email.service';


@Component({
    /*  selector:'pm-email', */
    templateUrl: './email.component.html',
    styles: ['thead{color:#337AB7;}']

})
export class EmailComponent implements OnInit {
    pageTitle: string = 'email';
    emails: ITextEmail[] = [];

    errorMessage: string;
    constructor(private _emailService: EmailService) {

    }


    ngOnInit(): void {
        // console.log('In OnInit')
        this._emailService.getEmails().subscribe(emails => {
            this.emails = emails;
            // this.filteredCustomers=this.customers;


        },
            error => this.errorMessage = <any>error
        );


    }


}


