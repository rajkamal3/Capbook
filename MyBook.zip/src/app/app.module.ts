import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppComponent } from './app.component';
import { HomepageComponent } from './homepage/homepage.component';
import { UserfeedComponent } from './userfeed/userfeed.component';
import { RouterModule } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { MessagesComponent } from './messages/messages.component';
import { SettingsComponent } from './settings/settings.component';
import { ProfileComponent } from './profile/profile.component';
import { GroupsComponent } from './groups/groups.component';
import { OnlineComponent } from './online/online.component';
import { RequestComponent } from './request/request.component';
import { StatusupdateComponent } from './statusupdate/statusupdate.component';
import { StatusnwallComponent } from './statusnwall/statusnwall.component';
import { MapsComponent } from './maps/maps.component';
import { CommentService } from '../api/comment.service';
import { ProfilewallComponent } from './profile/profilewall/profilewall.component';
import { BirthdaysComponent } from './notifications/birthdays.component';
import { FeedflowComponent } from './feedflow/feedflow.component';
import { ProfilefriendsComponent } from './profile/profilefriends/profilefriends.component';
import { ProfilephotosComponent } from './profile/profilephotos/profilephotos.component';
import { ProfileaboutmeComponent } from './profile/profileaboutme/profileaboutme.component';
import { AgmCoreModule } from '@agm/core';
import { LatService } from '../api/latlang/latlang.service';
import { AlbumComponent } from './profile/album/album.component';
import { ImagesComponent } from './profile/images/images.component';
import { CommonModule } from '@angular/common';
import { ProfileaboutmeService } from './profile/profileaboutme/profileaboutme.service';
import { ProfileService } from './profile/profile.service';
import { GroupProfileComponent } from './group-profile/group-profile.component';
import { HomegroupComponent } from './homegroup/homegroup.component';
import { GroupComponent } from './group/group.component';
import { DiscoverComponent } from './discover/discover.component';
import { GroupshomeComponent } from './groupshome/groupshome.component';
import { GroupsService } from '../api/groups/groups.service';
import { GroupProfileService } from '../api/group-profile/group-profile.service';
import { GrouphomepageComponent } from './grouphomepage/grouphomepage.component';
import { SearchGroupsComponent } from './search-groups/search-groups.component';
import { GroupsServiceImpl } from './search-groups/groups.service';
import { GroupProfileSearchComponent } from './group-profile.1/group-profile.component';
import { TopicComponent } from './GroupTopics/topic.component';
import { GroupRequestComponent } from './GroupTopics/grouprequest.component';
import { ApproveComponent } from './GroupTopics/approve.component';
import { GroupComponentAdmin } from './GroupTopics/groups.component';
import { ApproveService } from '../api/groupsAdmin/approve.service';
import { GRequestsService } from '../api/groupsAdmin/grouprequests.service';
import { GroupsServiceAdmin } from '../api/groupsAdmin/groups.service';
import { TopicService } from '../api/topics/topics.service';
import { EmailComponent } from './emails/email.component';
import { SmsComponent } from './sms/sms.component';
import { EmailService } from './emails/email.service';
import { SmsService } from './sms/sms.service';
import { ShowpostsComponent } from './showposts/showposts.component';
import { NewuserComponent } from './invitemail/newuser.component';
import { StatusService } from '../api/customer/showposts.service';
import { InviteService } from './invitemail/invite.service';
import { LikeComponent } from './like/like.component';
import { BdaysComponent } from './bdays/bdays.component';
import { LikeCommentService } from './like-comment/like-comment.service';
import { SearchUsersComponent } from './search-users/search-users.component';
import { UserprofileComponent } from './userprofile/userprofile.component';
import { UserprofileService } from './search-users/userprofile.service';
import { SearchUsersService } from './userprofile/search-users.service';
import { CustserviceService } from './custservice.service';
import { ChatComponent } from './chat/chat.component';
import { ChatService } from './chat.service';
import { FriendlistComponent } from './profile/friendlist/friendlist.component';
import { FriendlistService } from './service/friendlist.service';
import { ReferComponent } from './refer/refer.component';
import { ReferService } from './service/refer.service';
import { ListUploadComponent } from './upload/list-upload/list-upload.component';
import { FormUploadComponent } from './upload/form-upload/form-upload.component';
import { DetailsUploadComponent } from './upload/details-upload/details-upload.component';
import { UploadFileService } from './upload/upload-file.service';
import { TagComponent } from './tags/Tag.component';

@NgModule({
  declarations: [
    AppComponent,
    UserfeedComponent,
    HomepageComponent,
    MessagesComponent,
    SettingsComponent,
    ProfileComponent,
    GroupsComponent,
    OnlineComponent,
    RequestComponent,
    StatusupdateComponent,
    StatusnwallComponent,
    MapsComponent,
    ProfilewallComponent,
    BirthdaysComponent,
    FeedflowComponent,
    ProfilefriendsComponent,
    ProfilephotosComponent,
    ProfileaboutmeComponent,
    AlbumComponent,
    ImagesComponent,
    GroupProfileComponent,
    GroupProfileComponent,
    HomegroupComponent,
    GroupComponent,
    DiscoverComponent,
    GroupshomeComponent,
    GrouphomepageComponent,
    SearchGroupsComponent,
    GroupProfileSearchComponent,
    TopicComponent,
    GroupComponentAdmin,
    GroupRequestComponent,
    ApproveComponent,
    EmailComponent,
    SmsComponent,
    ShowpostsComponent,
    NewuserComponent,
    ShowpostsComponent,
    LikeComponent,
    BdaysComponent,
    SearchUsersComponent,
    UserprofileComponent,
    ChatComponent,
    FriendlistComponent,
    ReferComponent,
    ListUploadComponent,
    FormUploadComponent,
    DetailsUploadComponent,
    TagComponent
  ],

  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule,
    CommonModule,
    RouterModule.forRoot([
      { path: 'profile', component: ProfileComponent },
      { path: 'userfeed', component: UserfeedComponent },
      { path: 'messages', component: MessagesComponent },
      { path: 'settings', component: SettingsComponent },
      { path: 'groups', component: GroupsComponent },
      { path: 'notifications', component: BirthdaysComponent },
      { path: 'bdays', component: BdaysComponent },
      { path: 'profile/mywall', component: ProfilewallComponent },
      { path: 'profile/friendlist', component: FriendlistComponent },
      { path: 'profile/photos', component: ProfilephotosComponent },
      { path: 'profile/album', component: AlbumComponent },
      { path: 'profile/images', component: ImagesComponent },
      { path: 'profile/aboutme', component: ProfileaboutmeComponent },

      { path: 'home', component: HomegroupComponent },
      { path: 'groupshome', component: GroupshomeComponent },
      { path: 'discover', component: DiscoverComponent },
      { path: 'create', component: GroupComponent },
      { path: 'groupProfile', component: GroupProfileComponent },
      { path: 'groupHomeProfile', component: GrouphomepageComponent },
      { path: 'searchgroup', component: SearchGroupsComponent },
      { path: 'groupProfileSearch', component: GroupProfileSearchComponent },
      { path: 'groups/topics', component: TopicComponent },
      { path: 'groups/members', component: GroupRequestComponent },
      { path: 'groups/requests', component: ApproveComponent },
      { path: 'groupsadmin', component: GroupComponentAdmin },

      { path: 'email', component: EmailComponent },
      { path: 'sms', component: SmsComponent },

      { path: 'searchuser', component: SearchUsersComponent },
      { path: 'showuser', component: UserprofileComponent },

      { path: 'list', component: ChatComponent },
      { path: 'profile/refer', component: ReferComponent },
      { path: 'profile/tagvamshi', component: TagComponent }
    ]),

    AgmCoreModule.forRoot({
      apiKey: 'AIzaSyBYzXj5wF4L6mChyyc5xwfb2QT1QEZ9VN8'
    })
  ],

  providers: [
    CommentService,
    LatService,
    ProfileaboutmeService,
    ProfileService,
    GroupsService,
    GroupProfileService,
    GroupsServiceImpl,
    ApproveService,
    GRequestsService,
    GroupsServiceAdmin,
    TopicService,
    EmailService,
    SmsService,
    StatusService,
    InviteService,
    UserprofileService,
    SearchUsersService,
    CustserviceService,
    LikeCommentService,
    ChatService,
    FriendlistService,
    ReferService,
    UploadFileService
  ],

  bootstrap: [
    AppComponent,
    HomepageComponent,
    MapsComponent
  ]
})

export class AppModule { }
