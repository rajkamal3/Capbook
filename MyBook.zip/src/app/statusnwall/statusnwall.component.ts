import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'pm-statusnwall',
  templateUrl: './statusnwall.component.html',
  styleUrls: ['./statusnwall.component.css']
})
export class StatusnwallComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
