import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'pm-userfeed',
  templateUrl: './userfeed.component.html',
  styleUrls: ['./userfeed.component.css']
})
export class UserfeedComponent implements OnInit {

  public pageTitle: string = 'userfeed';

  constructor() { }

  ngOnInit() {
  }

}
