import { Component, OnInit } from '@angular/core';
import { ILatlang } from '../../api/latlang/latlang';
import { LatService } from '../../api/latlang/latlang.service';
import { MapsComponent } from '../maps/maps.component';
import { AgmCoreModule } from '@agm/core';


@Component({
  selector: 'pm-groups',
  templateUrl: './groups.component.html',
  styleUrls: ['./groups.component.css']
})
export class GroupsComponent implements OnInit {

  public pageTitle: string = 'groups';

  latlangs: ILatlang[] = [];

    _listFilter: string;
    errorMessage: string;
    constructor(private _latService: LatService) {
    }

    ngOnInit(): void {
      /* alert("hello") */
      this._latService.getdetails().subscribe(latlangs => {
        this.latlangs = latlangs;
    },
        error => this.errorMessage = <any>error
    );

    }
}
