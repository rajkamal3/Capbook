import { Component, OnInit } from '@angular/core';
import { Login } from '../loginpage/login';
import { loginService } from '../loginpage/loginservice';
import { UserProfile } from '../loginpage/userprofile';
import { Router, ActivatedRoute } from '@angular/router';
import { RouterModule, Routes } from '@angular/router';
import { DummypageComponent } from '../dummypage/dummypage.component';

@Component({
  selector: 'pm-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  login: Login = new Login();
  logs: Login = new Login();
  users: UserProfile = new UserProfile();
  logins: Login[] = [];
  flag: boolean = false;
  username: string;
  userid: number;


  constructor(private lgnservice: loginService, private router: Router) { }

  ngOnInit() {
  }


  getLogin(): void {

    console.log(this.login.email)
    this.lgnservice.getLogin(this.login).subscribe(users => {
    this.users = this.users;
      console.log(users);
      this.userid = users.userId;
      this.username = users.userName;
      localStorage.setItem('username', JSON.stringify(this.username));
      localStorage.setItem('userid', JSON.stringify(this.userid));
      this.router.navigate(["/homepage"])

    });

  }
}
