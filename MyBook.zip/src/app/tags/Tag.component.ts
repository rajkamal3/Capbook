import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpResponse, HttpEventType } from '@angular/common/http';
import { UploadFileService } from '../upload/upload-file.service';

@Component({
  selector: 'Tag-friend',
  templateUrl: './Tag.component.html',
  styleUrls: ['./Tag.component.css']
})
export class TagComponent implements OnInit {

  pageTitle: string = 'tagvamshi';

  title = 'Tag';
  description = 'Tag Your Friends';

  selectedFiles: FileList
  currentFileUpload: File
  url = '';
  progress: { percentage: number } = { percentage: 0 }

  constructor(private uploadService: UploadFileService) { }

  ngOnInit() {
  }

  selectFile(event) {

    if (event.target.files && event.target.files[0]) {
      var reader = new FileReader();

      reader.readAsDataURL(event.target.files[0]);

      /* reader.onload = (event) => {
        this.url = event.target.result;
      } */
    }

    if (event.target.files.item(0).type.match('image.*')) {
      this.selectedFiles = event.target.files;
    } else {
      alert('invalid format!');
    }
  }

  tag() {
    this.progress.percentage = 0;
    //alert(this.selectedFiles.item(0))
    this.currentFileUpload = this.selectedFiles.item(0)
    this.uploadService.pushFileToStorage(this.currentFileUpload).subscribe(event => {
      if (event.type === HttpEventType.UploadProgress) {
        this.progress.percentage = Math.round(100 * event.loaded / event.total);
      } else if (event instanceof HttpResponse) {
        console.log('File is completely uploaded!');
      }
    })

    this.selectedFiles = undefined;
  }

}