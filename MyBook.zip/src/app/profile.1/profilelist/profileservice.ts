import { Injectable } from "@angular/core";

import { HttpClient, HttpErrorResponse, HttpHeaders } from "@angular/common/http";
import { Observable } from "rxjs/Observable";
import "rxjs/add/observable/throw";
import "rxjs/add/operator/do";
import "rxjs/add/operator/catch";
import { friend } from "./friend";

const httpOptions ={
headers :new HttpHeaders({'Content-Type':'application/json'})
};
@Injectable()
export class smsService{
private pstfrnd='http://localhost:8083/frnd/friend';
private friend:friend[];
constructor(private _http:HttpClient){

} 
 
postFriend(frnd:friend):Observable<friend>
{
return this._http.post<friend>(this.pstfrnd,frnd,{})
} 
 
}