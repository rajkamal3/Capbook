import { Component, OnInit } from '@angular/core';
import { ChangePassword } from './changepassword';
import{ChangePasswordService} from './changepassword.service';
import { Router } from '../../../node_modules/@angular/router';
@Component({
  selector: 'pm-changepassword',
  templateUrl: './changepassword.component.html',
  styleUrls: ['./changepassword.component.css']
})
export class ChangepasswordComponent implements OnInit {
  public pageTitle : string ='changepassword';
  chngpsswd=new ChangePassword();
  id=localStorage.getItem('userid');
  constructor(private chngepsswdService:ChangePasswordService,private router:Router) { }

  ngOnInit() {
  }

  changePsswd(userid,newpsswd,oldpasswd){
    console.log(userid,newpsswd,oldpasswd)
    this.postPassword(userid,newpsswd,oldpasswd);
    alert("Pasword Successfully changed!!!")
    this.router.navigate(["/dummy"])
    window.location.reload();
  }
  postPassword(userid,newpsswd,oldpasswd):void{
    this.chngepsswdService.postPasswd(userid,newpsswd,oldpasswd).subscribe();
      
  }
}
