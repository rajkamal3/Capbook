export class ChangePassword {
    oldPassword : string ;
    newPassword : string ;
    newPasswordConfirm : string;
}