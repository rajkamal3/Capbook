
import { Injectable } from "../../../node_modules/@angular/core";
import { ChangePassword } from "./changepassword";
import  {  HttpClient,  HttpErrorResponse,  HttpHeaders  }  from  "@angular/common/http";
import { Observable } from "../../../node_modules/rxjs/Observable";

const httpOptions = {
    headers : new HttpHeaders ({ 'Content-Type' : 'application/json'})
};

@Injectable() 
export class ChangePasswordService {
    private postpwdUrl='http://localhost:8083/profileCreation/changepwd/';
    private changepwd : ChangePassword[];
    
     
    //id=JSON.parse(localStorage.getItem('userid'));
    constructor(private  _http: HttpClient) {

    }

    postPasswd(userid,newpsswd,oldpasswd): Observable<string> {
        console.log(userid,newpsswd,oldpasswd)
       this.postpwdUrl=this.postpwdUrl+userid+'/'+newpsswd+'/'+oldpasswd;
       return this._http.post<string>(this.postpwdUrl,{})
      

    }

}