export class ChangePassword{
    emailId:string;
	oldPassword:string;
	newPassword:string;
 
}