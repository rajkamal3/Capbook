
export class Chat{

    chat_id:number;
    user_sender_id:number;
    user_receiver_id:number;
    
}

export class Messages{

    
    message_Id:number;
    text:string;
    date:Date;
    
}