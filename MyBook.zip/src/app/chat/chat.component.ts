import { Component, OnInit } from '@angular/core';
import { Chat } from './chat';
import { Messages } from './chat';
import { ChatService } from '../chat.service';

@Component({
  selector: 'pm-chat',
  templateUrl: './chat.component.html',
  styleUrls: ['./chat.component.css']
})
export class ChatComponent implements OnInit {
  r_id: number;
  userid: number;
  public component: string = 'list';

  chat: Chat = new Chat();

  chats: Chat[];

  messages: Messages[];
  messagesRec: Messages[];
  message: Messages = new Messages();

  constructor(private charService: ChatService) { }
  ngOnInit() {

    this.chat.user_sender_id= JSON.parse(localStorage.getItem('userId'))
    this.chat.user_receiver_id = JSON.parse(localStorage.getItem('receiverId'))


    this.charService.getMessages(this.chat).subscribe(data => {
      this.messages = data;
      this.charService.getMessagesRec(this.chat).subscribe(data => {
        this.messagesRec = data;
      })
    })
  }

  getMessages(chat) {
    this.charService.getMessages(this.chat).subscribe(data => {
      this.messages = data;
    });
  };
  saveMessages(chat, message) {
    if (this.message.text != null) {
      this.charService.saveMessages(this.chat, this.message).subscribe(data => {
        this.chats = data;
        location.reload();
      })
    }
  }
}
