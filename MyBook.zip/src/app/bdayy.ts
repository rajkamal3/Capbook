
export class IBirthday {
    /*  customerId: number;
     firstName: string;
     lastName: string;
     dateOfBirth: string;
     emailId: string;
     mobile: string; */
    // userid :string

    //dob :string;
    user_name: string;

} 
