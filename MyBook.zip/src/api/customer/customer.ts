export interface ICustomer {
    customerId: number
    firstName: string
    lastName: string
    dateOfBirth: Date
    emailId: string
    mobile: string
    customerPwd: string
}