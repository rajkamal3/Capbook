export class IComment{
    commentId:number
	commentText:string
	postedBy:number
	postedTo:number
	dateOfPosting:Date
    likeCount:number
	dislikeCount:number
}