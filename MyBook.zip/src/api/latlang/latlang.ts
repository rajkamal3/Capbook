export interface ILatlang{
    id:number;
    city:string;
    latitude:number;
    longitude:number;
}