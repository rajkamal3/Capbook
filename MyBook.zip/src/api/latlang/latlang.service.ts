import { Injectable } from "@angular/core";
import { ILatlang } from "../../api/latlang/latlang";
import { HttpClient, HttpErrorResponse } from "@angular/common/http";
import { Observable } from "../../../node_modules/rxjs";
import { tap } from "../../../node_modules/rxjs/operators";
import { catchError } from "../../../node_modules/rxjs/operators";

@Injectable()
export class LatService{
    
    private _latUrl='http://localhost:8083/address/api/getdetails/1';
    
    constructor(private _http:HttpClient){

    }

    getdetails():Observable<ILatlang[]>{
        return  this._http.get<ILatlang[]>(this._latUrl).pipe(
        tap(data =>console.log('All:'+ JSON.stringify(data))))
        .pipe(catchError(this.handleError))
    }

    private handleError(err:HttpErrorResponse){
        console.error(err.message)
        return Observable.throw(err.message)
    }
    
    
}