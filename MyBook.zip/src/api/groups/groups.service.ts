import { Injectable } from "@angular/core";
import { IFriend } from "./friends";
import { HttpClient, HttpErrorResponse, HttpHeaders } from "@angular/common/http";
import { Observable } from "rxjs/Observable";
import "rxjs/add/observable/throw";
import "rxjs/add/operator/do";
import "rxjs/add/operator/catch";
import { IGroup, IPostT, IGroup2, IGroup1, User } from "./groups";
import { Subject } from "../../../node_modules/rxjs/Subject";
import { BehaviorSubject } from 'rxjs';
import { group } from "../../../node_modules/@angular/core/src/animation/dsl";
import { getTypeNameForDebugging } from "../../../node_modules/@angular/core/src/change_detection/differs/iterable_differs";
import { post } from "../../../node_modules/@types/selenium-webdriver/http";
import { GroupTopic, GroupComments } from "../group-profile/friends";

const httpOptions ={
    headers :new HttpHeaders({'Content-Type':'application/json'})
};
@Injectable()
export class GroupsService{
    public static groups:IGroup;
    private _friendUrl='http://localhost:8083/groups';
    _Url:string='http://localhost:8083/groups';
/*     private friend:IFriend;
 */    private getAllFriends:string='findall';
 public static gName:string;

 //public static gId:number;
 private subject = new Subject<any>();
 /* sendMessage(gName){
     this.subject.next({text:gName}); }
     clearMessage(){
         this.subject.next();
     }
     getMessage():Observable<any>{
         return this.subject.asObservable();

     } */
   
     
   
    constructor(private _http:HttpClient){

    }
    
 

    getFriends():Observable<IFriend[]>{
        this._friendUrl =this._Url+ '/'+this.getAllFriends;
        return  this._http.get<IFriend[]>(this._friendUrl)
 
    }
    createGroup(group:IGroup):Observable<IGroup>
    {
       
       
    // GroupsService.gId=group.groupId;
    
        this._friendUrl =this._Url+ '/'+'creategroup';
       // groupList:IGroup[] =this._http.post<IGroup[]>(this._friendUrl,group);
        return  this._http.post<IGroup>(this._friendUrl,group)

        
    }
    getComments(topic:GroupTopic):Observable<GroupComments[]>
    {
        this._friendUrl=this._Url+'/getComments/'+topic.topic_id;
        return this._http.get<GroupComments[]>(this._friendUrl);
    }
    postT(postT:GroupTopic):Observable<GroupTopic[]>
    {
     console.log(postT)
  
    
        this._friendUrl =this._Url+ '/'+'postT';
        return  this._http.post<GroupTopic[]>(this._friendUrl,postT)
    }
    getUserDetails(userId:number):Observable<User>
    {
this._friendUrl=this._Url+'/groups/findUser/'+userId;
return this._http.get<User>(this._friendUrl)
    }
  
    getGroups(groupAdmin:number){

        this._friendUrl=this._Url+'/'+'groupadmin'+'/'+groupAdmin;
        return this._http.get<IGroup1[]>(this._friendUrl)

}
getJoinedGroups(userId:number){
    this._friendUrl=this._Url+'/'+'groups'+'/'+userId;
    return this._http.get<IGroup2[]>(this._friendUrl)

}
}