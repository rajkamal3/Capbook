import { Injectable } from "@angular/core";
import { ITopic } from "../../api/topics/topics";
import { HttpClient, HttpErrorResponse } from "@angular/common/http";
import { Observable } from "../../../node_modules/rxjs";
import { GroupsServiceAdmin } from "../groupsAdmin/groups.service";




@Injectable()
export class TopicService{
    private _topicUrl='http://localhost:8083/groups/groupTopics';
    private _topicDeleteUrl='http://localhost:8083/groups/deleteTopics';
    public  topics:ITopic[]=[];
    
    constructor(private _http:HttpClient){

    }
    getTopics():Observable<ITopic[]>{
        this._topicUrl=this._topicUrl+"/"+GroupsServiceAdmin.group.groupId;
        return  this._http.get<ITopic[]>(this._topicUrl)
    }
    private handleError(err:HttpErrorResponse){
        console.error(err.message)
        return Observable.throw(err.message)
    }
    deleteTopics(groupId,topicId):Observable<ITopic[]>{
        this._topicDeleteUrl=this._topicDeleteUrl+'/'+groupId+'/'+topicId;

        return  this._http.delete<ITopic[]>(this._topicDeleteUrl)
        
    }
    
}