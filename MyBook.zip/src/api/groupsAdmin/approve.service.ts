import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { IGrequests } from "../../api/groupsAdmin/grequests";
import { GroupsServiceAdmin } from './groups.service';


const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};


@Injectable()
  
export class ApproveService {
  

  private apprvURL='http://localhost:8083/groups/getAllGroupRequests/';


  constructor(private http:HttpClient) { }

  getApprove (): Observable<IGrequests[]> {
    console.log("service")
    this.apprvURL=this.apprvURL +GroupsServiceAdmin.group.groupId;
   // console.log('Approve Request are here!' + this.http.get<IGrequests[]>(this.apprvURL))
    return this.http.get<IGrequests[]>(this.apprvURL)
     
     
  }
  update(approve :IGrequests): Observable<IGrequests>{
    return this.http.put<IGrequests>('http://localhost:8083/groups/status',approve,{})
  }


}
