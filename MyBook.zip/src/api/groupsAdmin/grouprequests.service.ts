import { Injectable } from "@angular/core";

import { HttpClient, HttpErrorResponse } from "@angular/common/http";
import { Observable } from "../../../node_modules/rxjs";

import { IGrequests } from './grequests';
import { GroupsServiceAdmin } from './groups.service';


@Injectable()
export class GRequestsService{
    private _groupUrl='http://localhost:8083/groups/getAllGroupMembers';
    private _deleteMemberUrl='http://localhost:8083/groups/deleteGroupMember';
    constructor(private _http:HttpClient){

    }
    getGroupMembers():Observable<IGrequests[]>{
        this._groupUrl=this._groupUrl+"/"+GroupsServiceAdmin.group.groupId;
        return  this._http.get<IGrequests[]>(this._groupUrl)

    }
    private handleError(err:HttpErrorResponse){
        console.error(err.message)
        return Observable.throw(err.message)
    }
    deleteGroupMember(groupId,userId):Observable<IGrequests[]>{
        this._deleteMemberUrl=this._deleteMemberUrl+'/'+groupId+'/'+userId;

        return  this._http.delete<IGrequests[]>(this._deleteMemberUrl)
    }
    
}