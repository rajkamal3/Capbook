import { Injectable } from "@angular/core";
import { IGroups } from "../../api/groupsAdmin/groups";
import { HttpClient, HttpErrorResponse } from "@angular/common/http";
import { Observable } from "../../../node_modules/rxjs";

import { ITopic } from '../topics/topics';


@Injectable()
export class GroupsServiceAdmin{
    
    userId = JSON.parse(localStorage.getItem('userId'));

    private _groupUrl='http://localhost:8083/groups/getGroups/'+this.userId;
    public static group:IGroups;
    constructor(private _http:HttpClient){

    }
    getGroups():Observable<IGroups[]>{
        
        return  this._http.get<IGroups[]>(this._groupUrl)
        
    }
    private handleError(err:HttpErrorResponse){
        console.error(err.message)
        return Observable.throw(err.message)
    }
    getTopics():Observable<ITopic[]>{
        return  this._http.get<ITopic[]>(this._groupUrl)
        
    
    }
}