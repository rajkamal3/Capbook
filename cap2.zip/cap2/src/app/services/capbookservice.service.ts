import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpParams } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { SignUp } from '../sign-up/sign-up';
import {map, catchError } from 'rxjs/operators'
import { Friendrequest } from '../friendrequest';
import { Friendlist } from '../friendlist';
import { Message } from '../message';
import { Post } from '../post';

@Injectable({
  providedIn: 'root'
})
export class CapbookserviceService {

  constructor(private httpClient:HttpClient) { }

  public acceptUserDetails(signUp:SignUp):Observable<SignUp>{
    let body=JSON.parse(JSON.stringify(signUp));
    console.log(body);
    return this.httpClient.post<SignUp>("http://localhost:3421/signUp",body).pipe(catchError(this.handleError));
  }
  public getUserDetails(emailid:string,password:string):Observable<SignUp>{
    let params = new HttpParams();
    params = params.set('emailid', emailid.toString()).set('password', password.toString());
    return this.httpClient.get<SignUp>("http://localhost:3421/signIn", {params : params}).pipe(catchError(this.handleError));
  }
  public getUserDetailsByEmail(emailid:string):Observable<SignUp>{
    let params = new HttpParams();
    params = params.set('emailid', emailid.toString());
    return this.httpClient.get<SignUp>("http://localhost:3421/profile", {params : params}).pipe(catchError(this.handleError));
  }
  public getAllUsers(emailid:string):Observable<SignUp[]>{
    let params = new HttpParams();
    params = params.set('emailid', emailid.toString());
    return this.httpClient.get<SignUp[]>("http://localhost:3421/findFriends", {params : params}).pipe(catchError(this.handleError));
  }
  public postFile(fileToUpload: File):any {
    const formData: FormData = new FormData();
    formData.append('Image', fileToUpload, fileToUpload.name);
    return this.httpClient.post("http://localhost:3421/setProfilePic", formData).pipe( map(() => { return true; }),
    catchError(this.handleError)); 
  }
  public sendPost(message:string):Observable<Post>{
    let params = new HttpParams();
    params = params.set('message', message.toString());
    console.log(params);
    return this.httpClient.get<Post>("http://localhost:3421/sendPost",{params : params}).pipe(catchError(this.handleError));
    
  }
  public getAllPosts():Observable<Post[]>{
    return this.httpClient.get<Post[]>("http://localhost:3421/getAllPosts",).pipe(catchError(this.handleError));
    
  }
  public getNotifications(emailid:string):Observable<Friendrequest[]>{
    let params = new HttpParams();
    params = params.set('emailid', emailid.toString());

    return this.httpClient.get<Friendrequest[]>("http://localhost:3421/getNotification", {params : params}).pipe(catchError(this.handleError));
  }
  public updateLike(post:Post):Observable<Post>{
    let body=JSON.parse(JSON.stringify(post));
    console.log(body);
    return this.httpClient.post<Post>("http://localhost:3421/updateLike",body).pipe(catchError(this.handleError));
  }
  public getUserFriendList(emailid:string):Observable<Friendlist[]>{
    let params = new HttpParams();
    params = params.set('emailid', emailid.toString());
    return this.httpClient.get<Friendlist[]>("http://localhost:3421/getFriendList", {params : params}).pipe(catchError(this.handleError));
  }
  public sendRequest(senderEmail:string,receiverEmail:string):Observable<Friendrequest>{
   console.log(senderEmail);
   console.log(receiverEmail);
    let params = new HttpParams();
    params = params.set('senderEmail',senderEmail.toString()).set('receiverEmail',receiverEmail.toString());
    return this.httpClient.get<Friendrequest>("http://localhost:3421/sendFriendRequest", {params : params}).pipe(catchError(this.handleError));
  }
  public acceptRequest(senderEmail:string,receiverEmail:string):Observable<Friendrequest>{
    let params = new HttpParams();
    params = params.set('senderEmail', senderEmail.toString()).set('receiverEmail', receiverEmail.toString());
    return this.httpClient.get<Friendrequest>("http://localhost:3421/acceptFriendRequest", {params : params}).pipe(catchError(this.handleError));
  }
  public updateProfile(signUp:SignUp):Observable<string>{
    let body=JSON.parse(JSON.stringify(signUp));
    console.log(body);
    return this.httpClient.post<string>("http://localhost:3421/updateProfile",body).pipe(catchError(this.handleError));
  }
  public forgotPassword(emailid:string,securityQuestion:string,securityAnswer:string,newPassword:string):Observable<SignUp>{
    let params = new HttpParams();
    params = params.set('emailid', emailid.toString()).set('securityQuestion', securityQuestion.toString()).set('securityAnswer', securityAnswer.toString()).set('newPassword', newPassword.toString());
    return this.httpClient.get<SignUp>("http://localhost:3421/forgotPassword", {params : params}).pipe(catchError(this.handleError));
  }
  public sendMessage(senderEmail:string,receiverEmail:string,textMessage:string):Observable<Message>{
    let params = new HttpParams();
    params = params.set('senderEmail', senderEmail.toString()).set('receiverEmail', receiverEmail.toString()).set('textMessage', textMessage.toString());
    return this.httpClient.get<Message>("http://localhost:3421/sendMessage", {params : params}).pipe(catchError(this.handleError));
  }
  public getSentMessage(senderEmail:string):Observable<Message[]>{
    let params = new HttpParams();
    params = params.set('senderEmail', senderEmail.toString());
    return this.httpClient.get<Message[]>("http://localhost:3421/getSentMessage", {params : params}).pipe(catchError(this.handleError));
  }
  public getReceivedMessage(receiverEmail:string):Observable<Message[]>{
    let params = new HttpParams();
    params = params.set('receiverEmail', receiverEmail.toString());
    return this.httpClient.get<Message[]>("http://localhost:3421/getReceivedMessage", {params : params}).pipe(catchError(this.handleError));
  }
  public changePassword(emailid:string,oldPassword:string,newPassword:string,confirmNewPassword:string):Observable<SignUp>{
    let params = new HttpParams();
    params = params.set('emailid', emailid.toString()).set('oldPassword', oldPassword.toString()).set('newPassword', newPassword.toString()).set('confirmNewPassword', confirmNewPassword.toString());
    console.log(params)
    return this.httpClient.get<SignUp>("http://localhost:3421/changePassword", {params : params}).pipe(catchError(this.handleError));
  }
  public deleteRequest(senderEmail:string,receiverEmail:string):Observable<string>{
    let params = new HttpParams();
    params = params.set('senderEmail', senderEmail.toString()).set('receiverEmail', receiverEmail.toString());
    return this.httpClient.get<string>("http://localhost:3421/deleteFriendRequest", {params : params}).pipe(catchError(this.handleError));
  }
  private handleError(error:any){
    if(error instanceof ErrorEvent){
      console.error(`1 An ErrorEvent occurred:`,error.error.message);
      return throwError(error.error.message);
    } else if(error instanceof HttpErrorResponse){
      console.error(`2 Backend returned code ${error.status}, body was: ${error.message}`);
      return throwError(`Backend returned code ${error.status}, body was: ${error.message}`); 
    }  else if(error instanceof TypeError){
      console.error(`3 TypeError has occurred ${error.message}, body was ${error.stack} `);
      return throwError(`TypeError has occurred ${error.message}, body was ${error.stack} `);
    }
}
}
