import { Component, OnInit } from '@angular/core';
import { SignUp } from '../sign-up/sign-up';
import { ActivatedRoute, Router } from '@angular/router';
import { CapbookserviceService } from '../services/capbookservice.service';

@Component({
  selector: 'app-forgot',
  templateUrl: './forgot.component.html',
  styleUrls: ['./forgot.component.css']
})
export class ForgotComponent implements OnInit {
  
  _emailid:string
  signUp:SignUp
  signup:SignUp
 emessage:string
 emessage1:string
  message:string="Password changed";
  _securityAnswer:string;
  _password:string

  get emailid():string{
    return this._emailid;
  }
  set emailid(value: string){
    this._emailid=value;
  }
  get securityAnswer():string{
    return this._securityAnswer;
  }
  set securityAnswer(value: string){
    this._securityAnswer=value;
  }
  get password():string{
    return this._password;
  }
  set password(value: string){
    this._password=value;
  }
  constructor(private route:ActivatedRoute,private router:Router,private capbookservice:CapbookserviceService) { }

  ngOnInit() {}
onSubmit(){
  this.capbookservice.getUserDetailsByEmail(this._emailid).subscribe(
    signUp=>{
      this.signUp=signUp;
    },
    errorMessage=>{
      this.emessage='Incorrect Emailid'
    }
  );
  
}
onButtonClicked(): void {
  
  this.capbookservice.forgotPassword(this._emailid,this.signUp.securityQuestion,this._securityAnswer,this._password).subscribe(
    signup=>{
      this.signup=signup;
      console.log(signup);
    },
    errorMessage=>{
      this.emessage1='Incorrect Details'
    }

    
  )
}
public navigateBack(): void{
  this.router.navigate(['/signIn'])
}
}
