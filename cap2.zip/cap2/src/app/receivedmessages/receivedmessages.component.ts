import { Component, OnInit } from '@angular/core';
import { SignUp } from '../sign-up/sign-up';
import { Message } from '../message';
import { ActivatedRoute, Router } from '@angular/router';
import { CapbookserviceService } from '../services/capbookservice.service';

@Component({
  selector: 'app-receivedmessages',
  templateUrl: './receivedmessages.component.html',
  styleUrls: ['./receivedmessages.component.css']
})
export class ReceivedmessagesComponent implements OnInit {

  signUp:SignUp
  messageList:Message[]
  messages:Message[]
  errorMessage:string

  constructor(private route:ActivatedRoute,private router:Router,private capBookSerivce:CapbookserviceService) { }

  ngOnInit() {
    this.signUp= JSON.parse(sessionStorage.getItem('signUp'));
    this.capBookSerivce.getReceivedMessage(this.signUp.emailid).subscribe(
      tempMessages=>{
        this.messages=tempMessages;
        this.messageList=this.messages;
      },
      errorMessage=>{
        this.errorMessage=errorMessage;
      }
    )

  }

}
