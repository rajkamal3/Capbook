import { Component, OnInit } from '@angular/core';
import { Friendrequest } from '../friendrequest';
import { ActivatedRoute, Router } from '@angular/router';
import { CapbookserviceService } from '../services/capbookservice.service';
import { SignUp } from '../sign-up/sign-up';

@Component({
  selector: 'app-notifications',
  templateUrl: './notifications.component.html',
  styleUrls: ['./notifications.component.css']
})
export class NotificationsComponent implements OnInit {
  email:string
  emailid:string
  friendrequestList:Friendrequest[]
  friendrequests:Friendrequest[];
  signUp:SignUp
  errorMessage:string
  constructor(private route:ActivatedRoute,private router:Router,private capbookservice:CapbookserviceService) { }

  ngOnInit() {
    this.signUp= JSON.parse(sessionStorage.getItem('signUp'));
    this.capbookservice.getNotifications(this.signUp.emailid).subscribe(
      tempfriendrequests=>{
        this.friendrequests=tempfriendrequests;
        this.friendrequestList=this.friendrequests;
      },
      errorMessage=>{
        this.errorMessage=errorMessage;
      }
    );
  }
  public navigateBack(): void{
    this.router.navigate(['/profile'])
  }

}
