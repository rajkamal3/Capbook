import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RejectfriendComponent } from './rejectfriend.component';

describe('RejectfriendComponent', () => {
  let component: RejectfriendComponent;
  let fixture: ComponentFixture<RejectfriendComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RejectfriendComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RejectfriendComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
