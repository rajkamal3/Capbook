import { SignUp } from './sign-up/sign-up';

export interface Post {
    message:string
    time:Date
    signUp:SignUp
    likes:number
}
