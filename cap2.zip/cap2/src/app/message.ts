export interface Message {
    senderEmail:string
    receiverEmail:string
    senderFullName:string
    receiverFullName:string
    textMessage:string
}
