import { Component, OnInit } from '@angular/core';
import { CapBookService } from 'src/app/services/cap-book.service';
import { Router } from '@angular/router';
import { Message } from 'src/app/message';
import { Profile } from 'src/app/profile';

@Component({
  selector: 'app-sent-messages',
  templateUrl: './sent-messages.component.html',
  styleUrls: ['./sent-messages.component.css']
})
export class SentMessagesComponent implements OnInit {

  constructor(private capbookService:CapBookService,private router:Router) { }
  title = 'CapBook';
  messages:Message[];
  profile:Profile;
  errorMessage:string;
  ngOnInit() {
    console.log('in submit of edit profile');
    this.capbookService.sentMessages().subscribe(
      messages=>{
        this.messages=messages;
        console.log(messages);
        this.profile = JSON.parse(sessionStorage.getItem('profile'));
      },
      errorMessage=>{
        this.errorMessage=errorMessage;
      })
  }

}
