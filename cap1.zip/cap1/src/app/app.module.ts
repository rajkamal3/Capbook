import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {MatButtonModule, MatToolbarModule } from '@angular/material';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { UserRegistrationComponent } from './user-registration/user-registration.component';
import { RouterModule } from '@angular/router';
import { CapBookService } from './services/cap-book.service';
import { UserLoginComponent } from './user-login/user-login.component';
import { HttpClientModule } from '@angular/common/http';
import { UserProfileComponent } from './user-profile/user-profile.component';
import { CapBookHomeComponent } from './cap-book-home/cap-book-home.component';
import { EditProfileComponent } from './edit-profile/edit-profile.component';
import { EditPhotoComponent } from './user-profile/edit-photo/edit-photo.component';
import { UserDetailsComponent } from './change-password/user-details.component';
import { ForgetPasswordComponent } from './forget-password/forget-password.component';
import { FindFriendsComponent } from './find-friends/find-friends.component';
import { UserPlusComponent } from './find-friends/user-plus/user-plus.component';
import { LogoutComponent } from './logout/logout.component'
import { MyFriendsComponent } from './my-friends/my-friends.component';
import { MyPostsComponent } from './my-posts/my-posts.component';
import { SendMessageComponent } from './Messages/send-message/send-message.component';
import { SelectFriendComponent } from './Messages/send-message/select-friend/select-friend.component';
import { SentMessagesComponent } from './Messages/sent-messages/sent-messages.component';
import { ReceivedMessagesComponent } from './Messages/received-messages/received-messages.component';



@NgModule({
  declarations: [
    AppComponent,
    UserRegistrationComponent,
    UserLoginComponent,
    UserProfileComponent,
    CapBookHomeComponent,
    UserDetailsComponent,
    EditProfileComponent,
    EditPhotoComponent,
    ForgetPasswordComponent,
    FindFriendsComponent,
    UserPlusComponent,
    LogoutComponent,
    MyFriendsComponent,
    MyPostsComponent,
    SendMessageComponent,
    SelectFriendComponent,
    SentMessagesComponent,
    ReceivedMessagesComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MatButtonModule,
    MatToolbarModule,
    ReactiveFormsModule,
    HttpClientModule,
    FormsModule,
    RouterModule.forRoot([
      {path: 'capBookHome',component: CapBookHomeComponent},
      {path:'',redirectTo:'capBookHome',pathMatch:'full'},
      {path: 'userProfile',component: UserProfileComponent},
      {path: 'userLogin',component: UserLoginComponent},
      {path: 'editProfile',component: EditProfileComponent},
      {path: 'editPhoto',component: EditPhotoComponent},
      {path: 'forgetPassword',component: ForgetPasswordComponent},
      {path:'userDetails',component:UserDetailsComponent},
      {path:'logout',component:LogoutComponent},
      {path:'myFriends',component:MyFriendsComponent},  
      {path:'myPosts',component:MyPostsComponent},  
      {path:'findFriends',component:FindFriendsComponent},
      {path:'sentMessages',component:SentMessagesComponent},
      {path:'receivedMessages',component:ReceivedMessagesComponent},
      {path:'sendMessage',component:SendMessageComponent}
      
    ])
  ],
  exports: [MatButtonModule, MatToolbarModule],
  providers: [CapBookService],
  bootstrap: [AppComponent]
})
export class AppModule { }
