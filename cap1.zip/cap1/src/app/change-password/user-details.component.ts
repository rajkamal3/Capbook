import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { CapBookService } from '../services/cap-book.service';
import { ActivatedRoute,Router } from '@angular/router';
import { Profile } from '../profile';
@Component({
  selector: 'app-user-details',
  templateUrl: './user-details.component.html',
  styleUrls: ['./user-details.component.css']
})
export class UserDetailsComponent implements OnInit {
  profile:Profile;
  submitted=false;
  errorMessage:string;
  message:Profile;
  constructor(private route:ActivatedRoute,private router:Router,private formBuilder: FormBuilder,private capbookService:CapBookService) { }
  changePasswordForm: FormGroup;
  ngOnInit() {
    this.profile = JSON.parse(sessionStorage.getItem('profile'));
      this.changePasswordForm = this.formBuilder.group({
          newPassword: ['', [Validators.required, Validators.minLength(6)]],
          confirmPassword: ['', [Validators.required, Validators.minLength(6)]],
      });
  }
  get f() { return this.changePasswordForm.controls; }
  onSubmit() {
     this.submitted = true;
       // stop here if form is invalid
    if (this.changePasswordForm.invalid) {
      return;
  }
     if((this.changePasswordForm.get('newPassword').value)!=(this.changePasswordForm.get('confirmPassword').value)){
      this.errorMessage="Password Does Not Match";
      alert(this.errorMessage);
      }
    else{
      console.log("In Else")
    this.capbookService.changePassword(this.changePasswordForm.get('newPassword').value).subscribe(
      message=>{
        this.message=message;
        alert(' Your Password Is Changed Sucessfuly!!');
        this.router.navigate(['userProfile']);
      },
      errorMessage=>{
        this.errorMessage=errorMessage;
      }
    )
    }  
  }
}
