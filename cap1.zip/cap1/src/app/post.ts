export interface Post {
    postId: number,
    emailId: string,
    postContent: string,
    noOfPostLikes: number,
    noOfPostDislikes: number,
    comments: string
}
