import { Component, OnInit } from '@angular/core';
import { CapBookService } from '../services/cap-book.service';
import { Router, ActivatedRoute } from '@angular/router';
import { Profile } from '../profile';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-logout',
  templateUrl: './logout.component.html',
  styleUrls: ['./logout.component.css']
})
export class LogoutComponent implements OnInit {
profile:Profile;
errorMessage:string;
  constructor(private httpClient: HttpClient, private route:ActivatedRoute,private router:Router,private capBookService:CapBookService) { }

  ngOnInit() {
    this.capBookService.logout().subscribe(
      profile=>{
        this.profile=profile;
        sessionStorage.setItem('profile', JSON.stringify(null));
        this.router.navigate(['/capBookHome']);
      },
      errorMessage=>{
        this.errorMessage=errorMessage;
        console.log('in error of logout');
      })
    
  }
}
