import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { CapBookService } from '../services/cap-book.service';
import { Router, ActivatedRoute } from '@angular/router';
import { Profile } from '../profile';

@Component({
  /* template: ` 
  <div> 
    <h2>Data from EditProfileComponent: {{ profile }} </h2> 
    <input [(ngModel)] = profile /> 
    <br><br> 
    <a [routerLink]="['/userProfile']"></a> 
  </div> 
  `, */
  selector: 'app-edit-profile',
  templateUrl: './edit-profile.component.html',
  styleUrls: ['./edit-profile.component.css']
})
export class EditProfileComponent implements OnInit {
  /* profile:Profile={
    emailId:'',
    password:'',
    firstName:'',
    lastName:'',
    dateOfBirth:'',
    gender:'',
    userBio:'',
    relationshipStatus:'',
    dateOfJoining:'',
    workPlace:'',
    currentCity:'',
    homeTown:'',
    highestEducation:''
  }; */
  /* get profile():Profile { 
    return this.capBookService.profile;
  } 
  set profile(profile: Profile) { 
    this.capBookService.profile=profile; 
  }  */
  profile:Profile;
  errorMessage:string; 
  constructor(private route:ActivatedRoute,private router:Router,private capBookService:CapBookService) {}

  ngOnInit() {
    this.profile = JSON.parse(sessionStorage.getItem('profile'));
  }
 
  editProfileForm = new FormGroup({
    
    designation: new FormControl(''),
    userBio: new FormControl(''),
    relationshipStatus: new FormControl(''),
    currentCity: new FormControl(''),
    highestEducation: new FormControl('')
  })
  onSubmit(){
    console.log('in submit of edit profile');
    this.capBookService.editProfile(this.editProfileForm).subscribe(
      profile=>{
        console.log('in success of edit profile');
        this.profile=profile;
        sessionStorage.setItem('profile', JSON.stringify(profile));
        alert("You have successfully updated your profile");
        this.router.navigate(['/userProfile',profile]);
      },
      errorMessage=>{
        console.log('in error of edit profile');
        this.errorMessage=errorMessage;
        this.router.navigate(['/userProfile']);
        //alert("Please enter valid credentials");
      })
  }
}
