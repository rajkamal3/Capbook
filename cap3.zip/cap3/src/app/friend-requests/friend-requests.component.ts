import { Component, OnInit } from '@angular/core';
import { UserService } from '../Services/user.service';
import { Router, ActivatedRoute } from '@angular/router';
import { stringify } from 'querystring';
import { User } from '../user';

@Component({
  selector: 'app-friend-requests',
  templateUrl: './friend-requests.component.html',
  styleUrls: ['./friend-requests.component.css']
})
export class FriendRequestsComponent implements OnInit {
  
  constructor(private router:Router, private userService:UserService,private route:ActivatedRoute) { 
    this._listFilter=""
  }
  ngOnInit() {
    this.user=JSON.parse(localStorage.getItem("user"));
    this.userIdreceiver=this.user.userId;
    this.userService.getfriendRequestList(this.userIdreceiver).subscribe(
      tempUsers=>{
        
        this.users=tempUsers;
        console.log(this.users)
        this.userList=this.users
      },
      error=>{
        this.errorMessage=error;
      }
    )
  }
  get listFilter(): string{
    return this._listFilter;
  }
  set listFilter(value: string){
    this._listFilter=value;
    this.userList=this.userList?this.doUserFilter(this._listFilter):this.users
  }
  error:string;
  userList:User[];
  users:User[];
  user:User;
  successMessage:string
  errorMessage:string
  userIdreceiver:number;
  _listFilter:string=''
  doUserFilter(filterBy:string):User[]{
    filterBy=filterBy.toLowerCase();
    return this.users.filter(user=> user.firstName.toLowerCase().indexOf(filterBy)!==-1);
  }
  acceptTheRequest(userIdSender:number,userIdreceiver:number,){
    this.userService.acceptRequest(userIdSender,userIdreceiver).subscribe(
      message=>{
        this.successMessage=message;
      },
      error=>{
        this.errorMessage=error;
      }
    )
  }
  rejectTheRequest(userIdSender:number,userIdreceiver:number){
    this.userService.rejectRequest(userIdSender,userIdreceiver).subscribe(
      message=>{
        this.successMessage=message;
      },
      error=>{
        this.errorMessage=error;
      }
    )
  }
}
