import { Time } from "@angular/common";

export interface Message {
    userIdSender:number;
    userIdreceiver:number;
    message:string;
    time:Time;
}
