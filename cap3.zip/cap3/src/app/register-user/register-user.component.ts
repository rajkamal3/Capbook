import { Component, OnInit } from '@angular/core';
import { UserService } from '../services/user.service';
import {ActivatedRoute,Router} from '@angular/router';
import { User } from '../user';

@Component({
  selector: 'app-register-user',
  templateUrl: './register-user.component.html',
  styleUrls: ['./register-user.component.css']
})
export class RegisterUserComponent implements OnInit {

  pageTitle: string = "Create a new account today"
  pageDescription: string ="It's free and always will be!"
  successMessage:string
  errorMessage:string

  constructor(private router:Router,private userService : UserService) { }

  ngOnInit() {
  }

  // get firstName():string{
  //   return this.firstName
  // }

  // set firstName(value:string){
  //   this.firstName=value
  // }

  // get lastName():string{
  //   return this.lastName
  // }

  // set lastName(value:string){
  //   this.lastName=value
  // }

  // get dob():string{
  //   return this.dob
  // }

  // set dob(value:string){
  //   this.dob=value
  // }

  // get emailId():string{
  //   return this.emailId
  // }

  // set emailId(value:string){
  //   this.emailId=value
  // }

  // get gender():string{
  //   return this.gender
  // }

  // set gender(value:string){
  //   this.gender=value
  // }

  // get password():string{
  //   return this.password
  // }

  // set password(value:string){
  //   this.password=value
  // }

  onSubmit(user:User){
    this.userService.registerUser(user).subscribe(
      message=>{
        this.successMessage=message
      },
      message=>{
        this.errorMessage=message
      }
    )
    this.router.navigate(['/login'])
  }
}